const canvas = document.getElementById("myCanvas");
const createCircleBtn = document.getElementById("createCircle");
const circleInput = document.getElementById("circleInput");
if (canvas) {
  const ctx = canvas.getContext("2d");
  const statusConfigs = {
    IDLE: 0,
    DRAG_START: 1,
    DRAGING: 2,
  };
  const circlesInfos = []; // 记录所有圆的坐标与半径
  const canvasInfos = {
    status: statusConfigs.IDLE,
    dragTarget: [],
    lastEventPos: { x: null, y: null },
  }; // 记录画布上拖拽状态
  const reg = /[0-9]{1,3},[0-9]{1,3},[0-9]{1,3}/;
  createCircleBtn.addEventListener("click", (e) => {
    if (reg.test(circleInput.value.split(","))) {
      const circleParams = {
        x: circleInput.value.split(",")[0],
        y: circleInput.value.split(",")[1],
        r: circleInput.value.split(",")[2],
      };
      circlesInfos.push(circleParams);
      drawCircle(ctx, circleParams.x, circleParams.y, circleParams.r);
    }
  });
  const drawCircle = (ctx, cx, cy, r) => {
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.closePath();
    ctx.restore();
  };
  const getCanvasPosition = (e) => {
    return {
      x: e.offsetX,
      y: e.offsetY,
    };
  };
  const gitDistance = (pos, circlesInfo) => {
    return (pos.x - circlesInfo.x) ** 2 + (pos.y - circlesInfo.y) ** 2;
  };
  const inCircles = (pos) => {
    let inCircleArr = [];
    for (let i = 0; i < circlesInfos.length; i++) {
      if (gitDistance(pos, circlesInfos[i]) < circlesInfos[i].r ** 2) {
        inCircleArr.push(circlesInfos[i]);
        circlesInfos.splice(i);
      }
    }
    return inCircleArr;
  };
  let pos = null;
  canvas.addEventListener("mousedown", (e) => {
    pos = getCanvasPosition(e);
    canvasInfos.dragTarget = inCircles(pos);
    canvasInfos.status = statusConfigs.DRAG_START;
    canvasInfos.lastEventPos = { x: pos.x, y: pos.y };
  });
  canvas.addEventListener("mousemove", (e) => {
    pos = getCanvasPosition(e);
    if (
      canvasInfos.status === statusConfigs.DRAG_START &&
      gitDistance(pos, canvasInfos.lastEventPos) > 100
    ) {
      console.log("trytodrag");
      canvasInfos.status = statusConfigs.DRAGING;
    } else if (canvasInfos.status === statusConfigs.DRAGING) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      console.log(circlesInfos);
      circlesInfos.forEach((item) => {
        drawCircle(ctx, item.x, item.y, item.r);
      });
      canvasInfos.dragTarget.forEach((item) => {
        drawCircle(
          ctx,
          item.x - 0 + pos.x - canvasInfos.lastEventPos.x,
          item.y - 0 + pos.y - canvasInfos.lastEventPos.y,
          item.r
        );
      });
    }
  });
  canvas.addEventListener("mouseup", (e) => {
    if (canvasInfos.status === statusConfigs.DRAGING) {
      canvasInfos.dragTarget.forEach((item) => {
        item.x = item.x - 0 + pos.x - canvasInfos.lastEventPos.x;
        item.y = item.y - 0 + pos.y - canvasInfos.lastEventPos.y;
        circlesInfos.push({ x: item.x, y: item.y, r: item.r });
      });
      canvasInfos.dragTarget = [];
      canvasInfos.lastEventPos = { x: null, y: null };
      pos = null;
      canvasInfos.status = statusConfigs.IDLE;
      console.log("Drag over");
    }
  });
}
