const compileUtil = {
  getVal(expr, vm) {
    return expr.split(".").reduce(
      (data, currentVal) => {
        return data[currentVal] || data;
      },
      typeof vm.$data === "object" ? vm.$data : vm.$data()
    );
  },
  setVal(expr, vm, inputVal) {
    expr.split(".").reduce(
      (data, currentVal) => {
        data[currentVal] = inputVal;
      },
      typeof vm.$data === "object" ? vm.$data : vm.$data()
    );
  },
  getContentVal(expr, vm) {
    return expr.replace(/\{\{(.+?)\}\}/g, (...args) => {
      return this.getVal(args[1], vm);
    });
  },
  text(node, expr, vm) {
    let value;
    if (expr.indexOf("{{") !== -1) {
      value = expr.replace(/\{\{(.+?)\}\}/g, (...args) => {
        new Watcher(vm, args[1], (newVal) => {
          this.updater.textUpdater(node, this.getContentVal(expr, vm));
        });
        return this.getVal(args[1], vm);
      });
    } else {
      value = this.getVal(expr, vm);
    }
    this.updater.textUpdater(node, value);
  },
  html(node, expr, vm) {
    const value = this.getVal(expr, vm);
    new Watcher(vm, expr, (newVal) => {
      this.updater.htmlUpdater(node, newVal);
    });
    this.updater.htmlUpdater(node, value);
  },
  model(node, expr, vm) {
    const value = this.getVal(expr, vm);
    new Watcher(vm, expr, (newVal) => {
      this.updater.modelUpdater(node, newVal);
    });
    node.addEventListener("input", (e) => {
      this.setVal(expr, vm, e.target.value);
    });
    this.updater.modelUpdater(node, value);
  },
  on(node, expr, vm, eventName) {
    let fn = vm.$options.methods && vm.$options.methods[expr];
    new Watcher(vm, expr, (newVal) => {
      node.addEventListener(newVal, fn.bind(vm), false);
    });
    node.addEventListener(eventName, fn.bind(vm), false);
  },
  bind(node, expr, vm, attrName) {
    const value = this.getVal(expr, vm);
    new Watcher(vm, expr, (newVal) => {
      this.updater.bindUpdater(node, attrName, newVal);
    });
    this.updater.bindUpdater(node, attrName, value);
  },
  updater: {
    textUpdater(node, value) {
      node.textContent = value;
    },
    htmlUpdater(node, value) {
      node.innerHTML = value;
    },
    modelUpdater(node, value) {
      node.value = value;
    },
    bindUpdater(node, attrName, value) {
      node[attrName] = value;
    },
  },
};
class Compile {
  constructor(el, vm) {
    this.el = this.isElementNode(el) ? el : document.querySelector(el);
    this.vm = vm;
    // 1.获取文档碎片对象，放入内存会减少页面的回流与重绘
    const fragment = this.node2Fragment(this.el);
    // 2.编译模板
    this.compile(fragment);
    // 3.追加子元素到根元素
    this.el.appendChild(fragment);
  }
  isElementNode(node) {
    return node.nodeType === 1;
  }
  node2Fragment(el) {
    //   创建文档碎片
    const f = document.createDocumentFragment();
    let firstChild;
    while ((firstChild = el.firstChild)) {
      f.appendChild(firstChild);
    }
    return f;
  }
  compile(fragment) {
    const childNodes = fragment.childNodes;
    [...childNodes].forEach((child) => {
      if (this.isElementNode(child)) {
        //   元素节点
        this.compileHtml(child);
      } else {
        //   文本节点
        this.compileText(child);
      }
      if (child.childNodes && child.childNodes.length) {
        this.compile(child);
      }
    });
  }
  compileHtml(node) {
    const attributes = node.attributes;
    [...attributes].forEach((attr) => {
      const { name, value } = attr;
      if (this.isDirective(name)) {
        const directive = name.split("-")[1];
        const [dirName, eventName] = directive.split(":"); // text html model
        compileUtil[dirName](node, value, this.vm, eventName);
        node.removeAttribute("v-" + directive);
      } else if (this.isEventName(name)) {
        let [, eventName] = name.split("@");
        compileUtil["on"](node, value, this.vm, eventName);
      } else if (this.isBindName(name)) {
        let [, attrName] = name.split(":");
        compileUtil["bind"](node, value, this.vm, attrName);
      }
    });
  }
  isDirective(attrName) {
    return attrName.startsWith("v-");
  }
  isEventName(attrName) {
    return attrName.startsWith("@");
  }
  isBindName(attrName) {
    return attrName.startsWith(":");
  }
  compileText(node) {
    const node_content = node.textContent;
    if (/\{\{(.+?)\}\}/.test(node_content)) {
      compileUtil["text"](node, node_content, this.vm);
    }
  }
}

class MyVue {
  constructor(options) {
    this.$el = options.el;
    this.$data = options.data;
    this.$options = options;
    if (this.$el) {
      // 实现一个观察者
      new Observer(this.$data);
      // 实现一个解析器
      new Compile(this.$el, this);
      this.proxyData(this.$data);
    }
  }
  proxyData(data) {
    for (const key in data) {
      console.log(data[key]);
      Object.defineProperty(this, key, {
        get() {
          return data[key];
        },
        set(newVal) {
          data[key] = newVal;
        },
      });
    }
  }
}
