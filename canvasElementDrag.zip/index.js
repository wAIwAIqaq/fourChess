const canvas = document.getElementById("myCanvas");
const createCircleBtn = document.getElementById("createCircle");
const circleInput = document.getElementById("circleInput");
if (canvas) {
  const ctx = canvas.getContext("2d");
  const statusConfigs = {
    IDLE: 0,
    DRAG_START: 1,
    DRAGING: 2,
  };
  const drawCircle = (ctx, cx, cy, r) => {
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.closePath();
    ctx.restore();
  };
  const circlesInfos = [{ x: 100, y: 100, r: 50 }]; // 记录所有圆的坐标与半径
  drawCircle(ctx, circlesInfos[0].x, circlesInfos[0].y, circlesInfos[0].r);
  const canvasInfos = {
    status: statusConfigs.IDLE,
    dragTarget: [],
    lastEventPos: { x: null, y: null },
    offset: {
      x: 0,
      y: 0,
    },
    scale: 1,
    scaleStep: 0.1,
    maxScale: 2,
    minScale: 0.5,
  }; // 记录画布上拖拽状态
  const reg = /[0-9]{1,3},[0-9]{1,3},[0-9]{1,3}/;
  createCircleBtn.addEventListener("click", (e) => {
    if (reg.test(circleInput.value.split(","))) {
      const circleParams = {
        x: circleInput.value.split(",")[0],
        y: circleInput.value.split(",")[1],
        r: circleInput.value.split(",")[2],
      };
      circlesInfos.push(circleParams);
      drawCircle(ctx, circleParams.x, circleParams.y, circleParams.r);
    }
  });
  const getCanvasPosition = (e, offset = { x: 0, y: 0 }, scale = 1) => {
    return {
      x: (e.offsetX - offset.x) / (scale || 1),
      y: (e.offsetY - offset.y) / (scale || 1),
    };
  };
  const getDistance = (pos, circlesInfo, offset = { x: 0, y: 0 }) => {
    return (pos.x - circlesInfo.x) ** 2 + (pos.y - circlesInfo.y) ** 2;
  };
  const inCircles = (pos) => {
    let inCircleArr = [];
    for (let i = circlesInfos.length - 1; i > -1; i--) {
      console.log(
        getDistance(pos, circlesInfos[i], canvasInfos.offset) <
          circlesInfos[i].r ** 2
      );
      if (getDistance(pos, circlesInfos[i]) < circlesInfos[i].r ** 2) {
        inCircleArr.push({ ...circlesInfos[i], index: i });
        circlesInfos.splice(i, 1);
      }
    }
    return inCircleArr;
  };
  const mouseInCircle = (pos) => {
    for (let i = circlesInfos.length - 1; i > -1; i--) {
      if (getDistance(pos, circlesInfos[i]) < circlesInfos[i].r ** 2) {
        return true;
      } else {
        return false;
      }
    }
  };
  let pos = null;
  canvas.addEventListener("mousedown", (e) => {
    pos = getCanvasPosition(e, canvasInfos.offset);
    canvasInfos.dragTarget = inCircles(pos);
    console.log(canvasInfos.dragTarget);
    canvasInfos.status = statusConfigs.DRAG_START;
    canvasInfos.lastEventPos = { x: pos.x, y: pos.y };
    console.log("darg start");
  });
  canvas.addEventListener("mousemove", (e) => {
    pos = getCanvasPosition(e, canvasInfos.offset, canvasInfos.scale);
    if (mouseInCircle(pos)) {
      canvas.style.cursor = "pointer";
    } else {
      canvas.style.cursor = "";
    }
    if (
      canvasInfos.status === statusConfigs.DRAG_START &&
      getDistance(pos, canvasInfos.lastEventPos) > 100
    ) {
      canvasInfos.status = statusConfigs.DRAGING;
    } else if (canvasInfos.status === statusConfigs.DRAGING) {
      console.log("moving");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      console.log(circlesInfos);
      circlesInfos.forEach((item) => {
        drawCircle(ctx, item.x, item.y, item.r);
      });
      canvasInfos.dragTarget.forEach((item) => {
        drawCircle(
          ctx,
          item.x - 0 + pos.x - canvasInfos.lastEventPos.x,
          item.y - 0 + pos.y - canvasInfos.lastEventPos.y,
          item.r
        );
      });
    }
  });
  canvas.addEventListener("mouseup", (e) => {
    canvasInfos.dragTarget.forEach((item) => {
      item.x = item.x - 0 + pos.x - canvasInfos.lastEventPos.x;
      item.y = item.y - 0 + pos.y - canvasInfos.lastEventPos.y;
      circlesInfos.splice(item.index, 0, { x: item.x, y: item.y, r: item.r });
    });
    canvasInfos.lastEventPos = { x: null, y: null };
    pos = null;
    console.log(circlesInfos);
    console.log("Drag over");
    canvasInfos.status = statusConfigs.IDLE;
  });
  canvas.addEventListener("wheel", (e) => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    e.preventDefault();
    const pos = getCanvasPosition(e, canvasInfos.offset);
    const deltaX = (pos.x / canvasInfos.scale) * canvasInfos.scaleStep;
    const deltaY = (pos.y / canvasInfos.scale) * canvasInfos.scaleStep;
    if (e.wheelDelta > 0 && canvasInfos.scale < canvasInfos.maxScale) {
      canvasInfos.offset.x -= deltaX;
      canvasInfos.offset.y -= deltaY;
      canvasInfos.scale += canvasInfos.scaleStep;
    } else if (e.wheelDelta <= 0 && canvasInfos.scale > canvasInfos.minScale) {
      canvasInfos.offset.x += deltaX;
      canvasInfos.offset.y += deltaY;
      canvasInfos.scale -= canvasInfos.scaleStep;
    }
    ctx.setTransform(
      canvasInfos.scale,
      0,
      0,
      canvasInfos.scale,
      canvasInfos.offset.x,
      canvasInfos.offset.y
    );
    circlesInfos.forEach((item) => {
      drawCircle(ctx, item.x, item.y, item.r);
    });
  });
}
